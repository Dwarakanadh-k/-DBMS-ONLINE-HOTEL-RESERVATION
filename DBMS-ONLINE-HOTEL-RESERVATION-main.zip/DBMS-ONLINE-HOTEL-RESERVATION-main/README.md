# DBMS-ONLINE-HOTEL-RESERVATION
ABSTRACT

This website facilitates the end user to view the hotel and hotel rooms based on the various categories and sorting preferences they select. It also lets the users register to the website so that his/her individual profile can be maintained. He/she can access and modify his/her profile by signing in. New users are given sign up option.

The user account maintains the personal details of the customer, both billing and room preference of the customer. Also, the reservation he/she has made can be viewed in the profile module. The user can cancel reservation prior to cancelation date of particular motel.

If the user is business owner, than he/she can add business to the Resme.com and manage business profile so customer can view services provided by them. Also, hotel owner can add and update business information along with amenities provided and picture of service. Price can be managed by the hotel owner based on their business models and services provided by them.

The system admin can add and manage the configurations of the website. She/he can add and modify the products, offers and manufacturers related to all the products. She/he can also create users for the system and assign them access rights based on the requirements and their job duty. System admin can also view various reports to fulfill certain job duty and reports help them to take decision and make business plans.
